#!/usr/bin/env python
# coding: utf-8

# ## Notebook 1
# 
# New notebook

# In[1]:


serverName = "testserver1123.database.windows.net"
database = "sampledb"
dbPort = 1433
dbUserName = "testuser"
dbPassword = "<<Your DB Password>>"


# In[2]:


from pyspark.sql import SparkSession


# In[3]:


spark = SparkSession.builder \
    .appName("Example") \
    .config("spark.jars.packages", "com.microsoft.azure:azure-sqldb-spark:1.0.2") \
    .config("spark.sql.catalogImplementation", "in-memory") \
    .config("spark.sql.catalog.testDB", "com.microsoft.azure.synapse.spark") \
    .config("spark.sql.catalog.testDB.spark.synapse.linkedServiceName", "AzureSqlDatabase") \
    .config("spark.sql.catalog.testDB.spark.synapse.linkedServiceName.connectionString", f"jdbc:sqlserver://{serverName}:{dbPort};database={database};user={dbUserName};password={dbPassword}") \
    .getOrCreate()



# In[4]:


jdbcURL = "jdbc:sqlserver://{0}:{1};database={2}".format(serverName,dbPort,database)
connection = {"user":dbUserName,"password":dbPassword,"driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"}


# In[5]:


df = spark.read.jdbc(url=jdbcURL, table = "SalesLT.Customer", properties=connection)


# In[6]:


df.write.mode("overwrite").format("delta").save("Tables/Employee")
